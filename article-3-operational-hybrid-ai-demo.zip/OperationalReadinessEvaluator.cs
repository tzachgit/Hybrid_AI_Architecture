using System.Text.Json;

namespace HybridAiOperatingModelDemo;

// Demonstration of an operational governance gate, not a production policy engine.
// The evaluator does not call a model. It checks whether organizational evidence
// is sufficient to begin a bounded pilot.

public enum GateDecision { ApproveBoundedPilot, Remediate, Block }

public sealed record ReadinessEvidence(
    bool BusinessOwnerAssigned,
    bool DataOwnerAssigned,
    bool ArchitectureReviewComplete,
    bool SecurityReviewComplete,
    bool PrivacyLegalReviewComplete,
    bool RiskRegisterComplete,
    bool EvaluationPlanComplete,
    bool TrainingPlanComplete,
    bool BaselineMetricsCaptured,
    bool IncidentPlaybookReady,
    bool HumanApprovalConfigured,
    bool ApprovedBudget,
    bool UsesProhibitedModel,
    bool ConsequentialAutonomousActions,
    bool KillSwitchReady);

public sealed record GateResult(
    GateDecision Decision,
    IReadOnlyList<string> BlockingItems,
    IReadOnlyList<string> Conditions,
    string PolicyVersion,
    string CorrelationId);

public static class OperationalReadinessEvaluator
{
    private const string PolicyVersion = "HAI-OM-001/1.0-demo";

    public static GateResult Evaluate(ReadinessEvidence e)
    {
        var blockers = new List<string>();
        var conditions = new List<string>();

        // Absolute policy blocks. These are not offset by a strong business case.
        if (e.UsesProhibitedModel)
            blockers.Add("A prohibited model or provider is included.");

        if (e.ConsequentialAutonomousActions && !e.HumanApprovalConfigured)
            blockers.Add("Consequential autonomous actions lack required human approval.");

        if (!e.BusinessOwnerAssigned)
            blockers.Add("No accountable business owner is assigned.");

        if (!e.SecurityReviewComplete)
            blockers.Add("Security review is incomplete.");

        if (!e.PrivacyLegalReviewComplete)
            blockers.Add("Privacy/legal review is incomplete.");

        // Required evidence for a useful and governable pilot.
        if (!e.DataOwnerAssigned) conditions.Add("Assign the accountable data owner.");
        if (!e.ArchitectureReviewComplete) conditions.Add("Complete architecture review.");
        if (!e.RiskRegisterComplete) conditions.Add("Complete risk register and ownership.");
        if (!e.EvaluationPlanComplete) conditions.Add("Define quality and safety evaluation.");
        if (!e.TrainingPlanComplete) conditions.Add("Complete role-based training plan.");
        if (!e.BaselineMetricsCaptured) conditions.Add("Capture baseline business metrics.");
        if (!e.IncidentPlaybookReady) conditions.Add("Prepare AI incident response path.");
        if (!e.ApprovedBudget) conditions.Add("Approve pilot budget and cost boundaries.");
        if (!e.KillSwitchReady) conditions.Add("Implement and test workflow kill switch.");

        GateDecision decision = blockers.Count > 0
            ? GateDecision.Block
            : conditions.Count > 0
                ? GateDecision.Remediate
                : GateDecision.ApproveBoundedPilot;

        return new GateResult(
            decision,
            blockers,
            conditions,
            PolicyVersion,
            Guid.NewGuid().ToString());
    }
}

public static class Demo
{
    public static void Main()
    {
        // Matches the incomplete intake example supplied with this demo.
        var evidence = new ReadinessEvidence(
            BusinessOwnerAssigned: true,
            DataOwnerAssigned: true,
            ArchitectureReviewComplete: true,
            SecurityReviewComplete: false,
            PrivacyLegalReviewComplete: false,
            RiskRegisterComplete: true,
            EvaluationPlanComplete: true,
            TrainingPlanComplete: true,
            BaselineMetricsCaptured: false,
            IncidentPlaybookReady: true,
            HumanApprovalConfigured: true,
            ApprovedBudget: false,
            UsesProhibitedModel: false,
            ConsequentialAutonomousActions: false,
            KillSwitchReady: true);

        GateResult result = OperationalReadinessEvaluator.Evaluate(evidence);
        Console.WriteLine(JsonSerializer.Serialize(
            result,
            new JsonSerializerOptions { WriteIndented = true }));

        // Expected decision: Block, because security and privacy/legal reviews are
        // mandatory in this illustrative policy. Missing baseline and budget also
        // appear as remediation conditions.
    }
}
