# Hybrid AI Operating Model Policy

**Policy ID:** HAI-OM-001  
**Version:** 1.0-demo  
**Owner:** AI Governance Council  
**Applies to:** AI systems that access organizational data, influence business decisions, generate externally consumed content, or take actions through tools or agents.

## 1. Operating principle

The organization does not measure success by the amount of AI used. It measures whether an approved AI capability produces a defined business outcome within acceptable risk, security, quality, compliance, and financial boundaries.

## 2. Governance principles

1. **Business ownership:** Every use case has one accountable business owner.
2. **Purpose limitation:** Data, models, tools, and actions are approved for a named purpose.
3. **Tiered access:** Local, approved remote, restricted, and prohibited models have different permitted workloads.
4. **Human accountability:** AI may assist or automate, but accountability remains assigned to a person or organizational role.
5. **Lifecycle governance:** Approval is not permanent; material changes trigger reassessment.
6. **Evidence before scale:** A pilot must demonstrate quality, control effectiveness, adoption, and business value before expansion.
7. **Safe failure:** If policy, classification, model health, or authorization is uncertain, the workflow stops or moves to human review.

## 3. Governance bodies

### AI Governance Council

- Approves risk tiers and enterprise AI policies.
- Resolves cross-functional exceptions.
- Assigns residual-risk acceptance authority.
- Reviews portfolio-level value and risk.

### Use-Case Review Team

Representatives from business, architecture, data, security, legal/compliance, risk, operations, and finance review each use case.

### Operational Owner

- Maintains the workflow.
- Watches service, quality, routing, incidents, and cost.
- Coordinates remediation and change control.

## 4. Lifecycle gates

### Gate 0: Idea

Required evidence:

- Named business problem
- Proposed users
- Expected benefit
- Initial data classes

### Gate 1: Discovery

Required evidence:

- Accountable owner
- Process map
- Local versus remote rationale
- Preliminary risk tier
- Human-oversight design

### Gate 2: Pilot approval

Required evidence:

- Approved model/provider tier
- Security and privacy review
- Risk register and control owners
- Test and evaluation plan
- Training plan
- Baseline business metrics
- Kill switch and incident path

### Gate 3: Production approval

Required evidence:

- Pilot results
- Quality and safety thresholds met
- Adoption readiness
- Operational support and monitoring
- Budget and benefit validation
- Accepted residual risks

### Gate 4: Ongoing operation

Required evidence:

- Periodic performance and risk reviews
- Model/provider change monitoring
- Incident trends
- Cost and ROI measurements
- Training completion

### Gate 5: Retirement

Required evidence:

- Access revoked
- Integrations disabled
- Data retention handled
- Records archived
- Users notified

## 5. Material-change triggers

Reassessment is required when any of the following changes:

- Model or model version
- Provider or commercial terms
- Data classification or new data source
- RAG corpus or retrieval permissions
- Tool/action permissions
- User population or jurisdiction
- Intended purpose
- Risk tolerance or applicable obligation
- Quality, incident, or cost behavior outside approved thresholds

## 6. Incident severity example

- **SEV-1:** Material safety, legal, regulatory, security, or external-customer harm. Disable affected workflow and invoke enterprise incident management.
- **SEV-2:** Significant incorrect behavior, sensitive-data exposure contained internally, or repeated control failure. Suspend the affected route and investigate.
- **SEV-3:** Isolated quality or operational issue without material impact. Record, correct, and trend.
- **SEV-4:** Improvement opportunity or minor user-experience issue.

## 7. Decision rights

- Business owner accepts business-process impact.
- Data owner approves access to governed data.
- Security approves security controls and exceptions.
- Legal/compliance determines applicable obligations.
- AI risk function assesses model/workflow risk.
- Finance validates cost and value assumptions.
- Designated executive accepts residual high risk.

## 8. Metrics

Metrics must cover four categories:

- **Value:** cycle time, effort, quality, revenue, cost, or risk reduction.
- **Risk/control:** incidents, policy violations, override rate, failed controls, and residual risk.
- **Operations:** availability, latency, escalation, model-routing distribution, and support load.
- **Adoption:** active use, training completion, satisfaction, and appropriate-use behavior.

Prompt volume, token volume, or user count may be diagnostic metrics, but they do not prove business value by themselves.
