# Article 3 Demo Set: Operationalizing Hybrid AI

This demo turns the operating-model concepts from Article 3 into a small, inspectable governance package.

## Scenario

A fictional enterprise wants to deploy **SupportAssist Hybrid**, an AI-assisted customer-support workflow. A local model retrieves approved internal knowledge and handles routine summarization. An approved remote model may be used for complex, non-sensitive reasoning. Consequential actions remain subject to human approval.

## What the package demonstrates

1. A versioned operating-model policy.
2. An AI use-case intake and approval record.
3. Role and accountability assignments.
4. A risk register with owners, controls, and residual-risk decisions.
5. A model/provider registry.
6. Training and adoption planning.
7. KPI and ROI definitions that measure business value, not merely AI activity.
8. A C# policy gate that decides whether a use case is ready for pilot, requires remediation, or must be blocked.
9. A sample monthly operating review.

## Continuous operating loop

`POLICY -> INTAKE -> RISK REVIEW -> APPROVAL -> PILOT -> MONITORING -> BUSINESS METRICS -> IMPROVEMENT -> POLICY`

## Files

- `hybrid-ai-operating-model.md` - policy, lifecycle, governance forums, escalation, and review cadence.
- `use-case-intake.yaml` - machine-readable intake for one AI use case.
- `raci-matrix.csv` - roles and responsibilities.
- `risk-register.csv` - risks, controls, ownership, and treatment.
- `model-registry.json` - approved local and remote model tiers.
- `training-adoption-plan.md` - shared and role-specific training.
- `kpi-roi-scorecard.json` - operational, risk, adoption, and value metrics.
- `OperationalReadinessEvaluator.cs` - annotated policy gate.
- `sample-monthly-review.md` - example governance review using synthetic values.

## Demonstration flow

1. Edit `use-case-intake.yaml` to describe a proposed use case.
2. Review the model tiers in `model-registry.json`.
3. Assign accountable owners using `raci-matrix.csv`.
4. Record risks and treatment in `risk-register.csv`.
5. Confirm training requirements in `training-adoption-plan.md`.
6. Run or inspect `OperationalReadinessEvaluator.cs`.
7. During the pilot, populate the KPI definitions in `kpi-roi-scorecard.json`.
8. Conduct a recurring review using `sample-monthly-review.md`.

> Demonstration only. The package contains synthetic data and does not replace legal, security, privacy, compliance, HR, finance, or risk-management review.
