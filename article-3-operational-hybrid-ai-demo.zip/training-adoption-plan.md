# Training and Adoption Plan

## Shared AI literacy for all users

Every participant must understand:

- Which AI services are approved.
- What information may and may not be entered.
- What the system does well and poorly.
- When output must be verified.
- How to report an incident or suspicious behavior.
- When AI must not be used.

## Role-specific tracks

### Support agents

- Review, edit, and approve AI drafts.
- Recognize unsupported or fabricated claims.
- Avoid entering prohibited data.
- Preserve accountability for customer communication.

### Managers and business owners

- Define outcomes and acceptable risk.
- Redesign workflows rather than merely adding AI to inefficient steps.
- Review adoption, quality, and value metrics.

### Technical and operations teams

- Operate local/remote routing, monitoring, fallback, and kill-switch controls.
- Manage model and provider versions.
- Preserve safe logs without exposing sensitive prompt content.

### Data stewards

- Maintain classification and access metadata.
- Review RAG sources and document permissions.
- Investigate classification failures.

### Security, risk, legal, and compliance

- Review trust boundaries, permissions, provider conditions, and action controls.
- Define evidence and retention expectations.
- Participate in incident exercises.

### Finance

- Validate baseline cost, operating cost, avoided cost, and benefit assumptions.
- Challenge value claims that rely only on prompt, token, or user counts.

## Adoption sequence

1. Communicate the problem being solved.
2. Train the pilot group.
3. Run bounded pilot with human approval.
4. Collect user feedback and operational evidence.
5. Correct workflow and training gaps.
6. Expand only after governance approval.

## Evidence

- Training completion
- Knowledge check results
- User feedback
- Policy acknowledgments
- Correct escalation behavior
- Reduction in unapproved AI use
