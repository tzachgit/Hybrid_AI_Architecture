# Hybrid AI Data Routing Policy Example

> **Purpose:** Demonstrate how an enterprise can route records to an internal AI or an approved external AI while applying Zero Trust, least privilege, data minimization, masking, and auditability.
>
> **Important:** This is an illustrative reference design, not production security or legal advice. Replace the sample rules with controls approved by your security, privacy, legal, compliance, and data-governance teams.

## 1. Scenario

A customer-support employee asks AI to summarize a support case and recommend the next action. The source record contains:

- Customer name
- Email address
- Account number
- Support description
- Internal risk score
- Payment-card number accidentally pasted into the description
- Internal notes containing proprietary troubleshooting guidance

The organization operates:

1. **Internal AI** inside an organization-controlled environment.
2. **Approved External AI** through a governed API.
3. **A Policy Enforcement Point (PEP)** that authenticates the caller, classifies the record, transforms the data, selects an approved route, and logs the decision.

## 2. Zero Trust principles applied

| Principle | Implementation in this example |
|---|---|
| Verify explicitly | Require an authenticated user, role, purpose, and approved workload before any model call. |
| Least privilege | Send each model only the fields necessary for the approved task. |
| Assume breach | Treat both local and external model calls as trust-boundary crossings; redact secrets, tokenize identifiers, and validate responses. |
| No implicit trust by location | Internal AI receives more data only because policy permits it, not merely because it is local. |
| Continuous enforcement | Re-evaluate every request; do not rely on a previous routing decision. |
| Auditability | Record policy version, route, transformations, reason codes, and correlation ID, but never log raw secrets. |

## 3. Data classification

| Field | Classification | Internal AI | External AI | Transformation |
|---|---|---:|---:|---|
| Case ID | Internal | Yes | Yes | Replace with request-scoped token externally. |
| Customer name | Confidential PII | Yes, if purpose requires it | No by default | Replace with `[CUSTOMER]`. |
| Email | Confidential PII | Yes, if purpose requires it | No | Remove or mask. |
| Account number | Restricted identifier | Yes for authorized roles | No | Tokenize using a reversible vault outside the model boundary. |
| Support description | Mixed | Yes after secret scanning | Yes after sanitization | Detect and redact card numbers, credentials, health data, and other prohibited content. |
| Internal risk score | Restricted business data | Yes for risk-authorized roles | No | Remove. |
| Internal notes | Proprietary / Alpha | Yes for approved internal workflows | No by default | Remove or summarize locally into a non-sensitive problem statement. |
| Payment-card number | Prohibited model input | No | No | Redact before either route and trigger a security event. |

## 4. Routing policy

Evaluate rules in this order:

1. **Deny prohibited content.** Secrets and payment-card numbers are removed before any model receives the record. The event is logged without recording the secret.
2. **Enforce purpose and role.** The caller must be authorized for the requested workload.
3. **Keep restricted or proprietary content internal.** If the task requires fields classified as Restricted or Proprietary, route only to an approved internal model.
4. **Minimize for external processing.** If an external model is permitted and useful, create a purpose-specific projection containing only the required fields.
5. **Fail closed.** If classification is uncertain, policy is unavailable, or no approved model is healthy, do not send the record externally. Route to manual review or return a controlled error.
6. **Validate the result.** Scan model output for prohibited disclosure and require human approval before consequential actions.

## 5. Example source record

```json
{
  "caseId": "CASE-10492",
  "customerName": "Avery Jordan",
  "email": "avery.jordan@example.com",
  "accountNumber": "ACCT-884291",
  "description": "Subscription failed. Card 4111 1111 1111 1111 was pasted here by mistake.",
  "internalRiskScore": 82,
  "internalNotes": "Proprietary recovery procedure: use the Blue Lantern workflow.",
  "requestedTask": "Summarize the problem and recommend the next support step."
}
```

## 6. Internal AI projection

The internal model receives only the fields required for the approved workflow. Even internally, the payment-card number is redacted.

```json
{
  "caseId": "CASE-10492",
  "customerName": "Avery Jordan",
  "accountToken": "tok_internal_7f91",
  "description": "Subscription failed. Card [PAYMENT_CARD_REDACTED] was pasted here by mistake.",
  "internalRiskScore": 82,
  "internalNotes": "Proprietary recovery procedure: use the Blue Lantern workflow.",
  "requestedTask": "Summarize the problem and recommend the next support step."
}
```

## 7. External AI projection

The external model receives a de-identified, minimized record. The organization retains the token-to-record mapping inside its own vault.

```json
{
  "caseToken": "req_01JH_CASE_01",
  "customerAlias": "[CUSTOMER]",
  "description": "Subscription failed. A prohibited payment value was removed before processing.",
  "requestedTask": "Summarize the technical problem and list generic diagnostic steps. Do not make account changes."
}
```

The external model does **not** receive the customer name, email, account number, risk score, proprietary recovery procedure, or original payment-card value.

## 8. Decision examples

### Example A: Internal route

- **Request:** Recommend the next action using the internal risk score and proprietary recovery procedure.
- **Decision:** Internal AI only.
- **Reason:** The task requires Restricted and Proprietary fields.
- **Human control:** A support lead must approve any account modification.

### Example B: External route after transformation

- **Request:** Produce generic troubleshooting suggestions for a subscription failure.
- **Decision:** Approved external AI.
- **Reason:** The task does not require identity, account, risk, or proprietary fields.
- **Transformation:** Remove PII, tokenize the case ID, redact prohibited values, exclude internal notes.

### Example C: Deny or manual review

- **Request:** Send the complete record to an unapproved public chatbot.
- **Decision:** Deny.
- **Reason:** Unapproved destination and prohibited sensitive content.

## 9. Audit event example

```json
{
  "correlationId": "0f2d2d9a-f8e7-4cf8-a603-6e34edf09c32",
  "policyVersion": "hybrid-ai-routing/1.0",
  "actorRole": "SupportAgent",
  "purpose": "GenericTroubleshooting",
  "route": "ApprovedExternalAi",
  "decision": "AllowAfterTransformation",
  "reasonCodes": [
    "PII_REMOVED",
    "ACCOUNT_TOKENIZED",
    "PAYMENT_VALUE_REDACTED",
    "PROPRIETARY_NOTES_EXCLUDED"
  ],
  "rawSensitiveDataLogged": false
}
```

## 10. Production hardening checklist

- Replace regex-only detection with approved data-loss-prevention and classification services.
- Use tokenization backed by a secure vault; do not invent reversible encoding schemes.
- Keep model credentials in a secrets manager.
- Authenticate users and workloads; authorize each request by role, purpose, and data class.
- Maintain an allowlist of approved model endpoints and versions.
- Encrypt transport and storage.
- Never log raw prompts or outputs without an explicit, reviewed retention policy.
- Scan both input and output for sensitive information.
- Limit RAG retrieval to documents the caller is authorized to access.
- Require human approval for consequential actions.
- Test policy failure, provider outage, classifier uncertainty, and prompt-injection scenarios.
- Version policies and preserve reason codes so decisions can be reconstructed.
