using System.Text.Json;
using System.Text.RegularExpressions;

namespace HybridAiRoutingExample;

// Demonstration only. Production systems should use approved identity, DLP,
// tokenization, secrets-management, policy-engine, and audit services.

public enum DataClass
{
    Public = 0,
    Internal = 1,
    Confidential = 2,
    Restricted = 3,
    Prohibited = 4
}

public enum AiRoute
{
    Deny,
    ManualReview,
    InternalAi,
    ApprovedExternalAi
}

public sealed record SupportCase(
    string CaseId,
    string CustomerName,
    string Email,
    string AccountNumber,
    string Description,
    int InternalRiskScore,
    string InternalNotes,
    string RequestedTask);

public sealed record RequestContext(
    string ActorId,
    string ActorRole,
    string Purpose,
    bool InternalModelHealthy,
    bool ExternalModelHealthy,
    bool ExternalProviderApproved);

public sealed record RoutingDecision(
    AiRoute Route,
    string Reason,
    object? ModelPayload,
    IReadOnlyList<string> Transformations,
    string CorrelationId,
    string PolicyVersion);

public static class HybridAiPolicy
{
    private const string PolicyVersion = "hybrid-ai-routing/1.0";

    // Demo detector only. Regex is not a complete DLP capability.
    // This pattern recognizes the common four-groups-of-four demonstration shape.
    private static readonly Regex CardLikePattern = new(
        @"\b(?:\d[ -]*?){13,19}\b",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public static RoutingDecision Evaluate(SupportCase record, RequestContext context)
    {
        string correlationId = Guid.NewGuid().ToString();
        var transformations = new List<string>();

        // ZERO TRUST CONTROL 1: Verify identity, role, and purpose for every request.
        // Do not trust the caller simply because the request originated internally.
        if (string.IsNullOrWhiteSpace(context.ActorId) ||
            string.IsNullOrWhiteSpace(context.ActorRole) ||
            string.IsNullOrWhiteSpace(context.Purpose))
        {
            return Deny("Missing verified identity, role, or business purpose.", correlationId);
        }

        if (!IsRoleAuthorized(context.ActorRole, context.Purpose))
        {
            return Deny("The caller is not authorized for the requested purpose.", correlationId);
        }

        // SECURITY CONTROL 2: Sanitize prohibited content before either model route.
        // A local model is not implicitly trusted with payment-card values or secrets.
        string sanitizedDescription = CardLikePattern.Replace(
            record.Description,
            match =>
            {
                transformations.Add("PAYMENT_VALUE_REDACTED");
                return "[PAYMENT_CARD_REDACTED]";
            });

        // SECURITY CONTROL 3: Classify the task based on the fields it requires.
        // In production, use explicit metadata and approved classification services.
        bool requiresRestrictedData =
            context.Purpose.Equals("AccountRiskDecision", StringComparison.OrdinalIgnoreCase) ||
            record.RequestedTask.Contains("risk score", StringComparison.OrdinalIgnoreCase);

        bool requiresProprietaryData =
            context.Purpose.Equals("InternalRecovery", StringComparison.OrdinalIgnoreCase) ||
            record.RequestedTask.Contains("recovery procedure", StringComparison.OrdinalIgnoreCase);

        // ROUTING RULE: Restricted or proprietary workloads are internal-only.
        if (requiresRestrictedData || requiresProprietaryData)
        {
            if (!context.InternalModelHealthy)
            {
                // FAIL CLOSED: never bypass policy by automatically sending the full
                // record to an external model because the internal model is unavailable.
                return new RoutingDecision(
                    AiRoute.ManualReview,
                    "Internal-only data is required, but the approved internal model is unavailable.",
                    null,
                    transformations,
                    correlationId,
                    PolicyVersion);
            }

            var internalPayload = new
            {
                record.CaseId,
                record.CustomerName,
                // Tokenization is represented here by a placeholder. A production token
                // must come from a secure vault and should not be derived in application logs.
                AccountToken = TokenizeForInternalUse(record.AccountNumber),
                Description = sanitizedDescription,
                record.InternalRiskScore,
                record.InternalNotes,
                record.RequestedTask
            };

            transformations.Add("ACCOUNT_TOKENIZED");

            return new RoutingDecision(
                AiRoute.InternalAi,
                "The approved task requires Restricted or Proprietary data.",
                internalPayload,
                transformations,
                correlationId,
                PolicyVersion);
        }

        // ROUTING RULE: External processing is allowed only when the provider is approved,
        // healthy, and the task can be completed using minimized, de-identified data.
        if (context.ExternalProviderApproved && context.ExternalModelHealthy)
        {
            var externalPayload = new
            {
                // Request-scoped token prevents disclosure of the source case identifier.
                CaseToken = $"req_{correlationId[..8]}",
                CustomerAlias = "[CUSTOMER]",
                Description = DescribeWithoutSensitiveValue(sanitizedDescription),
                RequestedTask =
                    "Summarize the technical problem and list generic diagnostic steps. " +
                    "Do not make account changes."
            };

            transformations.Add("PII_REMOVED");
            transformations.Add("CASE_ID_TOKENIZED");
            transformations.Add("INTERNAL_RISK_SCORE_EXCLUDED");
            transformations.Add("PROPRIETARY_NOTES_EXCLUDED");

            return new RoutingDecision(
                AiRoute.ApprovedExternalAi,
                "The task can be completed with a minimized, de-identified payload.",
                externalPayload,
                transformations.Distinct().ToArray(),
                correlationId,
                PolicyVersion);
        }

        // AVAILABILITY RULE: If external use is unavailable or unapproved, prefer the
        // approved internal model when it can safely perform the generic task.
        if (context.InternalModelHealthy)
        {
            var minimalInternalPayload = new
            {
                record.CaseId,
                Description = sanitizedDescription,
                record.RequestedTask
            };

            return new RoutingDecision(
                AiRoute.InternalAi,
                "External processing is unavailable or unapproved; use a minimized internal payload.",
                minimalInternalPayload,
                transformations,
                correlationId,
                PolicyVersion);
        }

        return new RoutingDecision(
            AiRoute.ManualReview,
            "No approved AI route is currently available.",
            null,
            transformations,
            correlationId,
            PolicyVersion);
    }

    public static bool OutputPassesDisclosureCheck(string modelOutput)
    {
        // Demonstration output gate. Production validation should use an approved
        // DLP/classification service and workload-specific validation rules.
        return !CardLikePattern.IsMatch(modelOutput) &&
               !modelOutput.Contains("Blue Lantern", StringComparison.OrdinalIgnoreCase) &&
               !modelOutput.Contains("@example.com", StringComparison.OrdinalIgnoreCase);
    }

    public static string CreateSafeAuditEvent(RoutingDecision decision, RequestContext context)
    {
        // Never include raw source records, complete prompts, access tokens, or model secrets.
        var audit = new
        {
            decision.CorrelationId,
            decision.PolicyVersion,
            context.ActorRole,
            context.Purpose,
            Route = decision.Route.ToString(),
            DecisionReason = decision.Reason,
            ReasonCodes = decision.Transformations,
            RawSensitiveDataLogged = false,
            OccurredAtUtc = DateTimeOffset.UtcNow
        };

        return JsonSerializer.Serialize(audit, new JsonSerializerOptions { WriteIndented = true });
    }

    private static RoutingDecision Deny(string reason, string correlationId) =>
        new(AiRoute.Deny, reason, null, Array.Empty<string>(), correlationId, PolicyVersion);

    private static bool IsRoleAuthorized(string role, string purpose)
    {
        // Small illustrative authorization matrix. Replace with enterprise policy evaluation.
        return (role, purpose) switch
        {
            ("SupportAgent", "GenericTroubleshooting") => true,
            ("SupportLead", "InternalRecovery") => true,
            ("RiskAnalyst", "AccountRiskDecision") => true,
            _ => false
        };
    }

    private static string TokenizeForInternalUse(string accountNumber)
    {
        // NON-PRODUCTION PLACEHOLDER. This creates a one-way demonstration token.
        // Use a reviewed tokenization service or vault if re-identification is required.
        return $"tok_internal_{Math.Abs(accountNumber.GetHashCode()):x8}";
    }

    private static string DescribeWithoutSensitiveValue(string sanitizedDescription)
    {
        // Convert the redaction marker into a neutral external description so the external
        // model learns only that prohibited data was removed, not what the value contained.
        return sanitizedDescription.Replace(
            "[PAYMENT_CARD_REDACTED]",
            "[PROHIBITED_VALUE_REMOVED]",
            StringComparison.Ordinal);
    }
}

public static class Demo
{
    public static void Main()
    {
        var source = new SupportCase(
            CaseId: "CASE-10492",
            CustomerName: "Avery Jordan",
            Email: "avery.jordan@example.com",
            AccountNumber: "ACCT-884291",
            Description: "Subscription failed. Card 4111 1111 1111 1111 was pasted here by mistake.",
            InternalRiskScore: 82,
            InternalNotes: "Proprietary recovery procedure: use the Blue Lantern workflow.",
            RequestedTask: "Summarize the technical problem and list generic diagnostic steps.");

        var request = new RequestContext(
            ActorId: "employee-771",
            ActorRole: "SupportAgent",
            Purpose: "GenericTroubleshooting",
            InternalModelHealthy: true,
            ExternalModelHealthy: true,
            ExternalProviderApproved: true);

        RoutingDecision decision = HybridAiPolicy.Evaluate(source, request);

        Console.WriteLine($"Route: {decision.Route}");
        Console.WriteLine($"Reason: {decision.Reason}");
        Console.WriteLine("Payload:");
        Console.WriteLine(JsonSerializer.Serialize(
            decision.ModelPayload,
            new JsonSerializerOptions { WriteIndented = true }));

        Console.WriteLine("Audit event:");
        Console.WriteLine(HybridAiPolicy.CreateSafeAuditEvent(decision, request));
    }
}
