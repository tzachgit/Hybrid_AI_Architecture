# Hybrid AI Workload Business Case

## 1. Business outcome
- Problem:
- Process owner:
- Users:
- Baseline metric:
- Target outcome:

## 2. Workload profile
- Data class:
- Alpha/IP sensitivity:
- Volume and concurrency:
- Latency expectation:
- Complexity/context:
- Multimodal/offline needs:
- Failure consequence:

## 3. Placement hypothesis
- Recommended: LocalFirst / RemoteFirst / Hybrid / HumanReview
- Why local helps:
- Why remote helps:
- Hard constraints:
- Human oversight:

## 4. Total-cost hypothesis
### Local
Hardware amortization, power, deployment, model lifecycle, engineering, operations.
### Remote
Consumption, platform charges, network/integration, vendor management.
### Shared
Security, governance, evaluation, monitoring, change management, training.

## 5. Pilot evidence required
- Quality
- Latency
- Cost per successful task
- Data/control compliance
- Availability
- User outcome
- Business KPI change

## 6. Decision
Proceed / redesign / stop. Document assumptions and owner.
