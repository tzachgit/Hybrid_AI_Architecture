namespace HybridAiArticle1Demo;

public enum Placement { LocalFirst, RemoteFirst, Hybrid, HumanReview }
public enum Level { Low, Medium, High }

public sealed record Workload(
 string Id, string Name, string DataClass, Level AlphaSensitivity, Level Volume,
 Level LatencyNeed, string Complexity, string ContextNeed, bool Multimodal,
 bool OfflineRequired, bool LocalCapabilityValidated, bool RemotePermitted, Level FailureImpact);

public sealed record Assessment(string WorkloadId, Placement Recommendation,
 int LocalFit, int RemoteFit, IReadOnlyList<string> Reasons);

public static class HybridAiWorkloadAssessor
{
 public static Assessment Assess(Workload w)
 {
  int local=0, remote=0; var why=new List<string>();

  // Strategic fit only. Runtime authorization/routing belongs to Article 2.
  if (w.AlphaSensitivity==Level.High || w.DataClass is "Restricted" or "Confidential") { local+=3; why.Add("Sensitive/Alpha-rich data favors organizational control."); }
  if (w.Volume==Level.High) { local+=2; why.Add("High recurring volume increases local-fit economics worth testing."); }
  if (w.LatencyNeed==Level.High) { local+=2; why.Add("Latency-sensitive workload favors a nearby execution path."); }
  if (w.OfflineRequired) { local+=4; why.Add("Offline operation requires a viable local path."); }

  if (w.Complexity is "High" or "Mixed") { remote+=3; why.Add("Complex reasoning increases hosted-capability fit."); }
  if (w.ContextNeed=="Large") { remote+=2; why.Add("Large context increases hosted-capability fit."); }
  if (w.Multimodal) { remote+=2; why.Add("Multimodal needs may favor an approved specialized hosted model."); }
  if (!w.LocalCapabilityValidated) { remote+=4; why.Add("Required capability has not been validated locally."); }

  // Hard constraints beat numeric scores.
  if (w.OfflineRequired && !w.LocalCapabilityValidated)
   return new(w.Id, Placement.HumanReview, local, remote, why.Append("Conflict: offline requirement but no validated local capability.").ToArray());

  if (!w.RemotePermitted)
  {
   if (w.LocalCapabilityValidated) return new(w.Id, Placement.LocalFirst, local, remote, why.Append("Remote processing is not permitted.").ToArray());
   return new(w.Id, Placement.HumanReview, local, remote, why.Append("Remote is prohibited and local capability is insufficient.").ToArray());
  }

  Placement p = local>=4 && remote>=4 ? Placement.Hybrid
              : local>remote && w.LocalCapabilityValidated ? Placement.LocalFirst
              : remote>local ? Placement.RemoteFirst
              : Placement.Hybrid;
  return new(w.Id,p,local,remote,why);
 }
}
