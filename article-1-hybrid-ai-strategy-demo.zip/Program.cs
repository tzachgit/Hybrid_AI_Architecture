using System.Text.Json;
using HybridAiArticle1Demo;

var workloads = new[] {
 new Workload("W-001","Internal policy FAQ","Internal",Level.Medium,Level.High,Level.High,"Low","Small",false,false,true,true,Level.Low),
 new Workload("W-002","Proprietary engineering knowledge assistant","Restricted",Level.High,Level.Medium,Level.High,"Medium","Medium",false,false,true,false,Level.High),
 new Workload("W-003","Public market research synthesis","Public",Level.Low,Level.Low,Level.Low,"High","Large",true,false,false,true,Level.Medium),
 new Workload("W-004","Customer service assistant","Confidential",Level.Medium,Level.High,Level.High,"Mixed","Medium",false,false,true,true,Level.Medium),
 new Workload("W-005","Field technician offline assistant","Internal",Level.Medium,Level.Medium,Level.High,"Medium","Small",true,true,true,true,Level.High),
 new Workload("W-006","Board strategy synthesis","Restricted",Level.High,Level.Low,Level.Low,"High","Large",false,false,false,false,Level.High)
};
var results=workloads.Select(HybridAiWorkloadAssessor.Assess);
Console.WriteLine(JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));
