# Article 1 Demo Set: Why Hybrid AI?

A pre-architecture decision kit for evaluating whether a workload belongs on local AI, approved remote AI, or a hybrid path. This complements Article 1's strategic "why" without duplicating Article 2's implementation router.

## Demo scenario
A fictional enterprise inventories candidate AI workloads and scores them across privacy, IP/Alpha sensitivity, latency, volume, capability, multimodal need, connectivity, and economics. The result is a **planning recommendation**, not an execution-time routing decision.

## Package
- `hybrid-ai-decision-framework.md` - strategic decision method and annotations.
- `workload-inventory.csv` - synthetic candidate workloads.
- `assessment-policy.yaml` - weights, hard constraints, and recommendation rules.
- `HybridAiWorkloadAssessor.cs` - annotated C# assessment engine.
- `Program.cs` / `HybridAiArticle1Demo.csproj` - console demo.
- `expected-assessments.json` - expected recommendations.
- `business-case-template.md` - one-page approval template.
- `pilot-scorecard.csv` - measures whether the hypothesis is true.
- `assumptions-and-guardrails.md` - important limits.

## Flow
`Inventory -> Classify Business/Data Needs -> Compare Local/Remote Fit -> Recommend Pattern -> Build Business Case -> Pilot -> Measure -> Reassess`

All organizations should replace demo weights and thresholds with their own risk appetite, policies, economics, hardware, and validated model capabilities.
