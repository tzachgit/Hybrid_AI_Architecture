# Assumptions and Guardrails

- The numeric weights are **illustrative**, not industry benchmarks.
- A planning recommendation is not permission to transmit data. Runtime security policy remains authoritative.
- "Local" does not automatically mean secure or inexpensive. Include hardware, power, operations, patching, evaluation, and model lifecycle.
- "Remote" does not automatically mean unsuitable. Use only approved providers, data classes, contracts, and controls.
- Do not assume a model family can satisfy a workload without workload-specific evaluation.
- Do not treat token cost alone as total cost.
- Do not count theoretical time savings as realized ROI until the organization shows how released capacity creates value.
- Reassess when models, providers, terms, data, workload volume, hardware, risk, or business outcomes materially change.
