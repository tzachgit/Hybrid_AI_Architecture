# Article 2 Demo Set: Building a Two-Tier AI Stack

This demonstration turns Article 2 into a compact, inspectable architecture for routing requests between local and approved remote AI.

## Scenario

A fictional enterprise application sends AI requests to a single gateway. The gateway evaluates:

1. Data sensitivity
2. User and workload authorization
3. Task type and complexity
4. Local-model capability and confidence
5. Model availability
6. Cost and latency budgets

It returns one of four outcomes:

- `LocalAi`
- `ApprovedRemoteAi`
- `HumanReview`
- `Deny`

## Architecture

`Application -> Policy/Classification -> Router -> Local AI or Approved Remote AI -> Local Validation -> Response`

Sensitive workloads fail closed. They never fall back to a remote model merely because the local model is unavailable.

## Files

- `architecture.md` - components, data flow, trust boundaries, and maturity path.
- `routing-policy.yaml` - readable routing and fallback rules.
- `model-catalog.json` - local, System-One, and remote model capabilities.
- `sample-requests.json` - synthetic requests covering local, remote, and blocked routes.
- `HybridAiRouter.cs` - annotated routing engine.
- `Program.cs` - demo runner.
- `HybridAiDemo.csproj` - .NET console-project definition.
- `expected-decisions.json` - expected route for every sample request.
- `observability-schema.md` - safe metrics, traces, logs, and alerts.
- `test-plan.md` - functional, security, resilience, quality, and cost tests.
- `sample-telemetry.jsonl` - synthetic telemetry events.

## Run

With .NET 8 or later installed:

```bash
dotnet run --project HybridAiDemo.csproj
```

The code uses mock model adapters and makes no network calls. Replace them only after security and architectural review.

> Demonstration only. The classifiers, thresholds, and token estimates are intentionally simplified. Production implementations need approved identity, DLP/classification, policy, secrets-management, model-serving, evaluation, and observability services.
