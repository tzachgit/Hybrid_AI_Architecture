# Hybrid AI Observability Schema

## Principle

Record enough evidence to reconstruct a routing decision without placing raw sensitive prompts, retrieved documents, credentials, or complete model outputs into general logs.

## Routing event

Recommended fields:

- `correlationId`
- `policyVersion`
- `requestId`
- `actorRole` rather than unnecessary personal identity
- `purpose`
- `dataClass`
- `taskType`
- `complexity`
- `selectedRoute`
- `selectedModelId`
- `ruleId`
- `localConfidenceBand`
- `estimatedInputTokens`
- `actualInputTokens` where available
- `latencyMs`
- `estimatedCostUsd`
- `actualCostUsd` where available
- `fallbackInvoked`
- `humanReviewRequired`
- `outputValidationStatus`
- `timestampUtc`

## Metrics

### Routing

- Percentage local, remote, human review, and denied
- Escalation rate by workload
- Fallback rate by model and reason

### Performance

- End-to-end latency
- Time to first token where meaningful
- Throughput and queue depth
- Local hardware utilization

### Quality

- Evaluation-set score by model/version
- Human correction rate
- Unsupported-claim rate
- Local-confidence calibration

### Cost

- Remote cost per successful task
- Local infrastructure allocation per task
- Retry and fallback cost

### Safety and governance

- Policy violations
- Data-classification uncertainty
- Sensitive-output detections
- Human-review completion

## Alerts

- Sensitive request attempts remote route
- Local confidence distribution changes materially
- Remote costs exceed budget
- Error or fallback rate crosses approved threshold
- Model/provider version changes without registry approval
- Output validation repeatedly fails
