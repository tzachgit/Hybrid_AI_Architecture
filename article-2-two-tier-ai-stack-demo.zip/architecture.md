# Two-Tier Hybrid AI Reference Architecture

## 1. Architectural objective

Use the least expensive and fastest **permitted** model that can meet the workload's quality requirements. Permission precedes capability; capability precedes cost optimization.

## 2. Logical components

### Application layer

Business applications call one organization-controlled AI gateway rather than individual providers.

### Identity and authorization

Verifies the user, workload, role, and declared purpose for every request.

### Data classifier

Classifies input as Public, Internal, Confidential, Restricted, or Prohibited. A production service should examine attached files, retrieved context, tool results, and metadata, not only prompt text.

### System-One decision layer

Produces bounded decisions such as:

- Task type
- Complexity band
- Local capability fit
- Escalation recommendation
- Confidence score

A decision model is not used here to write the final response. It helps the orchestration layer decide what should happen next.

### Policy and routing engine

Evaluates rules in this order:

1. Identity and authorization
2. Data class and destination restrictions
3. Required capability
4. Model health
5. Confidence threshold
6. Latency and cost budget
7. Approved fallback

### Local inference tier

Handles approved sensitive, routine, structured, retrieval, classification, and low-latency workloads.

### Approved remote tier

Handles permitted complex reasoning, large context, advanced multimodal work, or workloads outside the local tier's validated capability.

### Local validation and response gate

Validates output structure, searches for prohibited disclosure, records the route, and invokes human review where required.

## 3. Primary data flows

### Local-only

`Request -> Authenticate -> Classify -> Policy -> Local model -> Validate -> Return`

### Remote escalation

`Request -> Authenticate -> Classify -> Minimize -> Policy -> Approved remote model -> Local validation -> Return`

### Local, remote, local pipeline

1. Local classification and retrieval
2. Remote reasoning over permitted/minimized context
3. Local output validation, formatting, policy checks, and audit

### Fail-closed

`Sensitive request -> Local unavailable -> Human review / controlled failure`

No automatic remote fallback is permitted for data that cannot cross the boundary.

## 4. Architectural tradeoffs

- **Cost vs. capability:** local inference avoids repeated external calls but introduces hardware and operating costs.
- **Latency vs. quality:** local may reduce network delay, but performance still depends on model, hardware, concurrency, and workload.
- **Privacy vs. capability:** a more capable remote model remains unusable when policy prohibits the data transfer.
- **Resilience vs. consistency:** multiple models improve availability but require regression testing and output normalization.
- **Abstraction vs. optimization:** a unified interface reduces lock-in but can hide provider-specific features.

## 5. Maturity path

### Crawl

- Explicit rules
- One local and one approved remote model
- Basic logging
- Human fallback

### Walk

- Automated classification
- Confidence scoring
- Model health and fallback chains
- Cost and latency budgets

### Run

- Several specialized models
- Continuous evaluations
- Model abstraction
- Full traces, quality monitoring, and drift detection

### Autonomous orchestration

- Policy-bounded dynamic selection
- Continual routing optimization
- Automated regression and rollback
- Human control for consequential actions
