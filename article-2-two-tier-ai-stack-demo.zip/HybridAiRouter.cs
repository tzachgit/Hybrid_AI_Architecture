namespace HybridAiDemo;

public enum DataClass { Public, Internal, Confidential, Restricted, Prohibited }
public enum TaskType { Classification, Extraction, Retrieval, Summarization, StructuredTransformation, ComplexReasoning, Multimodal }
public enum Complexity { Low, Medium, High }
public enum Route { Deny, HumanReview, LocalAi, ApprovedRemoteAi }

public sealed record AiRequest(
    string Id,
    string ActorRole,
    string Purpose,
    bool Authorized,
    DataClass DataClass,
    TaskType TaskType,
    Complexity Complexity,
    int EstimatedInputTokens,
    bool RequiresMultimodal,
    bool LocalModelHealthy,
    bool RemoteModelHealthy,
    bool LocalCapabilityValidated,
    double LocalConfidence,
    bool RemoteAllowed,
    decimal EstimatedRemoteCostUsd);

public sealed record RoutingDecision(
    string RequestId,
    Route Route,
    string RuleId,
    string Reason,
    IReadOnlyList<string> RequiredControls,
    string CorrelationId,
    string PolicyVersion);

public static class HybridAiRouter
{
    private const string PolicyVersion = "hybrid-routing/1.0-demo";
    private const double LocalConfidenceMinimum = 0.82;
    private const int RemoteTokenMaximum = 12_000;
    private const decimal RemoteCostMaximum = 0.25m;

    public static RoutingDecision Decide(AiRequest r)
    {
        var controls = new List<string> { "Authenticate", "Authorize", "AuditRoute" };

        // 1. Authorization precedes model capability.
        if (!r.Authorized)
            return Result(r, Route.Deny, "DENY-001", "Caller or purpose is not authorized.", controls);

        // 2. Prohibited data is not accepted by either model tier in this demo.
        if (r.DataClass == DataClass.Prohibited)
            return Result(r, Route.Deny, "DENY-002", "Prohibited data cannot be sent to an AI model.", controls);

        // 3. Restricted and Confidential requests remain local unless a different,
        // explicitly reviewed policy creates a minimized remote projection.
        bool sensitive = r.DataClass is DataClass.Restricted or DataClass.Confidential;
        if (sensitive)
        {
            controls.Add("KeepDataLocal");
            controls.Add("ValidateOutputLocally");

            if (!r.LocalModelHealthy)
                return Result(r, Route.HumanReview, "FAIL-001",
                    "Sensitive workload requires local processing, but the local model is unavailable.", controls);

            if (!r.LocalCapabilityValidated || r.LocalConfidence < LocalConfidenceMinimum)
                return Result(r, Route.HumanReview, "CONF-002",
                    "Local quality is insufficient and remote escalation is not permitted.", controls);

            return Result(r, Route.LocalAi, "LOCAL-001",
                "Sensitive workload is authorized and within validated local capability.", controls);
        }

        // 4. Use local inference for validated routine work when confidence is sufficient.
        bool routineTask = r.TaskType is TaskType.Classification or TaskType.Extraction or
            TaskType.Retrieval or TaskType.Summarization or TaskType.StructuredTransformation;

        if (routineTask && r.LocalModelHealthy && r.LocalCapabilityValidated &&
            r.LocalConfidence >= LocalConfidenceMinimum && !r.RequiresMultimodal)
        {
            controls.Add("ValidateOutputLocally");
            return Result(r, Route.LocalAi, "LOCAL-002",
                "Routine workload fits the validated local capability and confidence threshold.", controls);
        }

        // 5. Escalate only when the destination is permitted, healthy, and inside
        // explicit token and cost budgets. The external payload must be minimized.
        bool remoteWithinBudget = r.EstimatedInputTokens <= RemoteTokenMaximum &&
                                  r.EstimatedRemoteCostUsd <= RemoteCostMaximum;

        if (r.RemoteAllowed && r.RemoteModelHealthy && remoteWithinBudget)
        {
            controls.Add("MinimizeExternalPayload");
            controls.Add("UseApprovedGateway");
            controls.Add("ValidateRemoteOutputLocally");
            return Result(r, Route.ApprovedRemoteAi, "REMOTE-001",
                "Workload needs capability beyond the local path and satisfies remote policy conditions.", controls);
        }

        // 6. A missing safe route is a designed path, not an excuse to bypass policy.
        return Result(r, Route.HumanReview, "FAIL-002",
            "No healthy, permitted, and budget-compliant model route is available.", controls);
    }

    private static RoutingDecision Result(AiRequest r, Route route, string rule, string reason,
        IReadOnlyList<string> controls) =>
        new(r.Id, route, rule, reason, controls, Guid.NewGuid().ToString(), PolicyVersion);
}
