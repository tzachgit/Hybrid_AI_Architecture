using System.Text.Json;
using HybridAiDemo;

var json = File.ReadAllText("sample-requests.json");
var document = JsonDocument.Parse(json);
var results = new List<RoutingDecision>();

foreach (JsonElement item in document.RootElement.GetProperty("requests").EnumerateArray())
{
    var request = new AiRequest(
        item.GetProperty("id").GetString()!,
        item.GetProperty("actorRole").GetString()!,
        item.GetProperty("purpose").GetString()!,
        item.GetProperty("authorized").GetBoolean(),
        Enum.Parse<DataClass>(item.GetProperty("dataClass").GetString()!),
        Enum.Parse<TaskType>(item.GetProperty("taskType").GetString()!),
        Enum.Parse<Complexity>(item.GetProperty("complexity").GetString()!),
        item.GetProperty("estimatedInputTokens").GetInt32(),
        item.GetProperty("requiresMultimodal").GetBoolean(),
        item.GetProperty("localModelHealthy").GetBoolean(),
        item.GetProperty("remoteModelHealthy").GetBoolean(),
        item.GetProperty("localCapabilityValidated").GetBoolean(),
        item.GetProperty("localConfidence").GetDouble(),
        item.GetProperty("remoteAllowed").GetBoolean(),
        item.GetProperty("estimatedRemoteCostUsd").GetDecimal());

    results.Add(HybridAiRouter.Decide(request));
}

Console.WriteLine(JsonSerializer.Serialize(results,
    new JsonSerializerOptions { WriteIndented = true }));
