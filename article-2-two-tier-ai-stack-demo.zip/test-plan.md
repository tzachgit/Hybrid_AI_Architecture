# Two-Tier AI Test Plan

## 1. Functional routing

- Routine internal classification routes locally.
- Permitted complex reasoning routes remotely.
- Restricted data never routes remotely.
- Unauthorized requests are denied.
- Multimodal tasks use only an approved capable route.
- Low local confidence escalates only when remote use is permitted.

## 2. Failure and resilience

- Local unavailable + restricted data -> HumanReview.
- Remote unavailable + local capable -> LocalAi.
- Both tiers unavailable -> HumanReview.
- Policy service unavailable -> fail closed.
- Classifier uncertainty -> HumanReview.
- Rate-limit response -> approved fallback only.

## 3. Security and data flow

- Confirm external projection excludes prohibited fields.
- Confirm direct provider endpoints are inaccessible to users.
- Confirm logs do not contain raw secrets or full sensitive prompts.
- Test prompt injection in user input and retrieved documents.
- Confirm RAG retrieval honors source permissions.

## 4. Quality

- Compare local and remote outputs on a held-out workload-specific evaluation set.
- Measure confidence calibration, not merely raw accuracy.
- Record human correction and rejection rates.
- Regression-test every model, provider, prompt, RAG, and routing-policy change.

## 5. Performance and cost

- Measure latency at normal and peak concurrency.
- Measure local saturation and queue behavior.
- Verify remote token and cost estimates against actual values.
- Confirm budgets prevent uncontrolled escalation.

## 6. Observability

- Every decision has a correlation ID, rule ID, policy version, and route.
- Alerts fire for prohibited routing and repeated validation failures.
- Operators can reconstruct a decision without accessing unnecessary sensitive content.
